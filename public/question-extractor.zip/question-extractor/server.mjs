import express from 'express';
import multer from 'multer';
import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import ZAI from 'z-ai-web-dev-sdk';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const upload = multer({ limits: { fileSize: 10 * 1024 * 1024 } });

let zaiInstance = null;
async function getZAI() {
  if (!zaiInstance) zaiInstance = await ZAI.create();
  return zaiInstance;
}

const SYSTEM_PROMPT = `You are an expert exam question extractor. Extract MCQs from images.

RULES:
1. Extract EVERY question visible
2. Each: 4 options (A,B,C,D)
3. Identify correct answer
4. Include explanation if visible
5. Preserve Hindi/English
6. Include passage if exists

Return ONLY JSON array:
[{"order":1,"question":"","optionA":"","optionB":"","optionC":"","optionD":"","correctOption":"A","explanation":"","passage":""}]`;

app.get('/', (req, res) => {
  const html = readFileSync(join(__dirname, 'public', 'index.html'), 'utf-8');
  res.type('html').send(html);
});

app.post('/api/extract', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No image' });

    const buf = req.file.buffer;
    const b64 = buf.toString('base64');
    const mime = req.file.mimetype || 'image/png';

    console.log(`📷 Extracting (${(buf.length/1024).toFixed(1)}KB)...`);
    const zai = await getZAI();
    const resp = await zai.chat.completions.createVision({
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: [
          { type: 'text', text: 'Extract all MCQs. Return ONLY JSON array []' },
          { type: 'image_url', image_url: { url: `data:${mime};base64,${b64}` } }
        ]}
      ],
      thinking: { type: 'disabled' }
    });

    let raw = (resp.choices[0]?.message?.content || '').trim();
    if (raw.startsWith('```')) raw = raw.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '');

    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) throw new Error('not array');
    const questions = arr.map((q, i) => ({
      order: q.order || i+1, question: q.question || '',
      optionA: q.optionA || '', optionB: q.optionB || '',
      optionC: q.optionC || '', optionD: q.optionD || '',
      correctOption: ['A','B','C','D'].includes(q.correctOption) ? q.correctOption : 'A',
      explanation: q.explanation || '', passage: q.passage || '',
      negativeMark: q.negativeMark || 0, section: q.section || 'General',
    }));

    console.log(`✅ ${questions.length} questions extracted`);
    res.json({ success: true, questions });
  } catch (e) {
    console.error('❌', e.message);
    res.status(500).json({ error: e.message || 'Failed' });
  }
});

app.listen(3006, () => console.log('🚀 Question Extractor Bot at http://localhost:3006'));
