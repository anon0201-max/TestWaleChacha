import ZAI from 'z-ai-web-dev-sdk';
import { readFile } from 'fs/promises';
import { join } from 'path';

const PORT = 3006;
let zaiInstance: any = null;

async function getZAI() {
  if (!zaiInstance) zaiInstance = await ZAI.create();
  return zaiInstance;
}

const SYSTEM_PROMPT = `You are an expert exam question extractor. Extract multiple-choice questions (MCQs) from images.

STRICT RULES:
1. Extract EVERY question visible
2. Each question: exactly 4 options (A, B, C, D)
3. Identify correct answer
4. Include explanation if visible
5. Clean OCR artifacts
6. Preserve question numbers
7. Preserve Hindi/English mixed content
8. Include passage in "passage" field if exists

Return ONLY valid JSON array. No markdown.

[{"order":1,"question":"","optionA":"","optionB":"","optionC":"","optionD":"","correctOption":"A","explanation":"","passage":""}]`;

async function extractFromImage(base64: string, mime: string) {
  const zai = await getZAI();
  const resp = await zai.chat.completions.createVision({
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content: [
        { type: 'text', text: 'Extract all MCQs. Return ONLY JSON array []' },
        { type: 'image_url', image_url: { url: `data:${mime};base64,${base64}` } }
      ]}
    ],
    thinking: { type: 'disabled' }
  });

  let raw = (resp.choices[0]?.message?.content || '').trim();
  if (raw.startsWith('```')) raw = raw.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '');

  try {
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) throw new Error('not array');
    return arr.map((q: any, i: number) => ({
      order: q.order || i + 1, question: q.question || '',
      optionA: q.optionA || '', optionB: q.optionB || '',
      optionC: q.optionC || '', optionD: q.optionD || '',
      correctOption: ['A','B','C','D'].includes(q.correctOption) ? q.correctOption : 'A',
      explanation: q.explanation || '', passage: q.passage || '',
      negativeMark: q.negativeMark || 0, section: q.section || 'General',
    }));
  } catch {
    throw new Error('AI returned invalid JSON. Try clearer image.');
  }
}

async function handleExtract(req: Request) {
  try {
    const form = await req.formData();
    const file = form.get('image') as File | null;
    if (!file) return Response.json({ error: 'No image' }, { status: 400 });
    if (file.size > 10*1024*1024) return Response.json({ error: 'Max 10MB' }, { status: 400 });

    const buf = await file.arrayBuffer();
    const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
    const mime = file.type || 'image/png';

    console.log(`📷 Extracting (${(file.size/1024).toFixed(1)}KB)...`);
    const questions = await extractFromImage(b64, mime);
    console.log(`✅ ${questions.length} questions extracted`);
    return Response.json({ success: true, questions });
  } catch (e: any) {
    console.error('❌', e.message);
    return Response.json({ error: e.message || 'Failed' }, { status: 500 });
  }
}

const HTML = await readFile(join(process.cwd(), 'public', 'index.html'), 'utf-8');

Bun.serve({
  port: PORT,
  fetch(req) {
    const url = new URL(req.url);
    if (url.pathname === '/') return new Response(HTML, { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    if (url.pathname === '/api/extract' && req.method === 'POST') return handleExtract(req);
    return new Response('Not Found', { status: 404 });
  },
});

console.log(`🚀 Question Extractor Bot at http://localhost:${PORT}`);
